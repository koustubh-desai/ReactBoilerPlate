/**
 *
 * Board
 *
 */

import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { createStructuredSelector } from 'reselect';
import { compose } from 'redux';

import { useInjectReducer } from 'utils/injectReducer';
import makeSelectBoard from './selectors';
import reducer from './reducer';
import * as Actions from './actions';
import Row3 from '../../components/Row3';

export function Board({board,dispatch,moveMade}) {
  useInjectReducer({ key: 'board', reducer });
  /*class Jojo extends React.Component{
    
    gameOver = false;
    constructor(props){
      super(props);
      this.gameOver = false;
    } 
    componentWillReceiveProps(){
      console.log('in componentWillReceiveProps');
    }
    componentWillUpdate(){
      console.log('in componentWillUpdate');
    }
    myClickHandler(event){
      if(this.gameOver) return;
      //moveMade(event.target.id);
      console.log('jojo',dispatch(Actions.play(event.target.id)));
      //setTimeout(()=>{
        this.gameOver = this.calculateWinner();
        if(this.gameOver) console.log(" and the winner is ",this.gameOver);
      //},2000)
    }
    calculateWinner(){
      let w;
      console.log('in calculate winner',board.moves);
      w = this.compare(0,1,2); if(w) return w;
      w = this.compare(0,4,8); if(w) return w;
      w = this.compare(3,4,5); if(w) return w;
      w = this.compare(6,7,8); if(w) return w;
      w = this.compare(2,4,6); if(w) return w;
      return false;
    }
    compare(a,b,c){
      if( (board.moves[a] === 'X' || board.moves[a] === 'O') &&
        (board.moves[a] == board.moves[b] && board.moves[b] == board.moves[c])
        ) return board.moves[a];
    }
    render(){
      console.log('in render',board.moves);
      return(<div onClick={this.myClickHandler.bind(this)}> 
      <Row3 id={0} xo={board.moves.slice(0,4)}/>
      <Row3 id={1} xo={board.moves.slice(3,6)}/>
      <Row3 id={2} xo={board.moves.slice(6,9)}/>
    </div>);
    }
  }
  return <Jojo {...board,dispatch,moveMade}/>;*/
  return <div onClick={(event)=>moveMade(event.target.id)}> 
      <Row3 id={0} xo={board.moves.slice(0,4)} winBy={board.winsBy}/>
      <Row3 id={1} xo={board.moves.slice(3,6)} winBy={board.winsBy}/>
      <Row3 id={2} xo={board.moves.slice(6,9)} winBy={board.winsBy}/>
    </div>
}

Board.propTypes = {
  dispatch: PropTypes.func.isRequired,
  moveMade:PropTypes.func,
  board:PropTypes.shape({
    moves:PropTypes.array,
    winsBy:PropTypes.array
  })
};

const mapStateToProps = createStructuredSelector({
  board: makeSelectBoard(),
});

function mapDispatchToProps(dispatch) {
  return {
    dispatch,
    moveMade:(position)=>dispatch(Actions.play(position)) && dispatch(Actions.checkWinner())
  };
}

const withConnect = connect(
  mapStateToProps,
  mapDispatchToProps,
);

export default compose(withConnect)(Board);
