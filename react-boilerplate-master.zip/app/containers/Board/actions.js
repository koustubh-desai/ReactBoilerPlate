/*
 *
 * Board actions
 *
 */

import { DEFAULT_ACTION, PLAY, CHECK_WINNER } from './constants';

export function defaultAction() {
  return {
    type: DEFAULT_ACTION,
  };
}
export function play(position){
  return{
    type: PLAY,
    position
  }
}
export function checkWinner(){
  return{
    type: CHECK_WINNER
  }
}
