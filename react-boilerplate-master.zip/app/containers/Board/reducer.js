/*
 *
 * Board reducer
 *
 */
import produce from 'immer';
import { DEFAULT_ACTION,PLAY,CHECK_WINNER} from './constants';

export const initialState = {
  moves:['','','','','','','','',''],
  nextPlayer:'X',
  wins:'',
  winsBy:[]
};

/* eslint-disable default-case, no-param-reassign */
const boardReducer = (state = initialState, action) =>
  produce(state, draft => {
    switch (action.type) {
      case DEFAULT_ACTION:
        break;
      case PLAY:
        if(state.moves[action.position]){
          //Handle error condition
          return {...state}; 
        }
        draft.moves = state.moves;
        draft.moves[action.position] = state.nextPlayer;
        draft.nextPlayer = state.nextPlayer === 'X'?'O':'X';
        break;
      case CHECK_WINNER:
        let w = checkPattern(state.moves);
        console.log('jojo',state.moves,w);
        draft.wins = w?w.pop():'';
        draft.winsBy = w?w:[];
        //draft.winsBy = w; 
        break;
    }
  }); 

  function checkPattern(arr){
    return (compare(arr,0,1,2) || compare(arr,0,4,8) || compare(arr,3,4,5) || 
            compare(arr,6,7,8) || compare(arr,2,4,6));
  }
  
  function compare(arr,a,b,c){
    if( (arr[a] === 'X' || arr[a] === 'O') &&
      (arr[a] == arr[b] && arr[b] == arr[c])
      ) return [a,b,c,arr[a]];
      return '';
  }

export default boardReducer;
