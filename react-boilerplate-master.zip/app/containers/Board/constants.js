/*
 *
 * Board constants
 *
 */

export const DEFAULT_ACTION = 'app/Board/DEFAULT_ACTION';
export const PLAY = 'app/Board/PLAY_ACTION';
export const CHECK_WINNER = 'app/Board/CHECK_WINNER';