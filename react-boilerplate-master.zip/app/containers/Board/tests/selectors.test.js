// import { selectBoardDomain } from '../selectors';

describe('selectBoardDomain', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
