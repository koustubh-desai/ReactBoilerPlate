/*
 *
 * Tictac constants
 *
 */

export const DEFAULT_ACTION = 'app/Tictac/DEFAULT_ACTION';
