/**
 *
 * Tictac
 *
 */

import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { createStructuredSelector } from 'reselect';
import { compose } from 'redux';

import { useInjectReducer } from 'utils/injectReducer';
import makeSelectTictac from './selectors';
import reducer from './reducer';
import './index.css';
import Row from './../../components/Row';

export function Tictac() {
  useInjectReducer({ key: 'tictac', reducer });

  return <div className="tictac">
    <Row/>
    <Row/>
    <Row/>
  </div>;
}

Tictac.propTypes = {
  dispatch: PropTypes.func.isRequired,
};

const mapStateToProps = createStructuredSelector({
  tictac: makeSelectTictac(),
});

function mapDispatchToProps(dispatch) {
  return {
    dispatch,
  };
}

const withConnect = connect(
  mapStateToProps,
  mapDispatchToProps,
);

export default compose(withConnect)(Tictac);
