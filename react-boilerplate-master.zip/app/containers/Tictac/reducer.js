/*
 *
 * Tictac reducer
 *
 */
import produce from 'immer';
import { DEFAULT_ACTION } from './constants';

export const initialState = {
  matrix:[[0,0,0],[0,0,0],[0,0,0]]
};

/* eslint-disable default-case, no-param-reassign */
const tictacReducer = (state = initialState, action) =>
  produce(state, (/* draft */) => {
    console.log('in tictacreducer');
    switch (action.type) {
      case DEFAULT_ACTION:
        break;
    }
  });

export default tictacReducer;
