import { createSelector } from 'reselect';
import { initialState } from './reducer';

/**
 * Direct selector to the tictac state domain
 */

const selectTictacDomain = state => state.tictac || initialState;

/**
 * Other specific selectors
 */

/**
 * Default selector used by Tictac
 */

const makeSelectTictac = () =>
  createSelector(
    selectTictacDomain,
    substate => substate,
  );

export default makeSelectTictac;
export { selectTictacDomain };
