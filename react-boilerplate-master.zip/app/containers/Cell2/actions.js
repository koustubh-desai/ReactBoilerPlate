/*
 *
 * Cell2 actions
 *
 */

import { DEFAULT_ACTION,CELL_CLICKED } from './constants';

export function defaultAction() {
  return {
    type: DEFAULT_ACTION,
  };
}

export function clickAction(cellPosition){
  console.log('in clickAction',cellPosition)
  return {
    type:CELL_CLICKED,
    cellPosition
  }
}
