// import { selectCell2Domain } from '../selectors';

describe('selectCell2Domain', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
