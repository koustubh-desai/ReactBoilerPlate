/**
 *
 * Cell2
 *
 */

import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { createStructuredSelector } from 'reselect';
import { compose } from 'redux';

import { useInjectReducer } from 'utils/injectReducer';
import makeSelectCell2 from './selectors';
import reducer from './reducer';
import {clickAction} from './actions';

export function Cell2({onClickHandler}) {
  useInjectReducer({ key: 'cell2', reducer });

  return <div className="cell" onClick={()=>onClickHandler(event)}></div>;
}

Cell2.propTypes = {
  onClickHandler:PropTypes.func 
};

const mapStateToProps = createStructuredSelector({
  cell2: makeSelectCell2()
});

function mapDispatchToProps(dispatch) {
  return {
    onClickHandler:(evt)=>dispatch(clickAction(evt)),
  };
}

const withConnect = connect(
  mapStateToProps,
  mapDispatchToProps,
);

export default compose(withConnect)(Cell2);
