/*
 *
 * Cell2 constants
 *
 */

export const DEFAULT_ACTION = 'app/Cell2/DEFAULT_ACTION';
export const CELL_CLICKED = 'CellClicked';
