/*
 *
 * Cell2 reducer
 *
 */
import produce from 'immer';
import { DEFAULT_ACTION,CELL_CLICKED } from './constants';

export const initialState = {
  value:0
};

/* eslint-disable default-case, no-param-reassign */
const cell2Reducer = (state = initialState, action) =>
  produce(state, (draft) => {
    switch (action.type) {
      case DEFAULT_ACTION:
        break;
      case CELL_CLICKED:
        console.log('what is the draft',draft,initialState);
        draft.value = new Date();
        break;
    }
  });

export default cell2Reducer;
