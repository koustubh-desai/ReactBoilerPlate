import { createSelector } from 'reselect';
import { initialState } from './reducer';

/**
 * Direct selector to the cell2 state domain
 */

const selectCell2Domain = state => state.cell2 || initialState;

/**
 * Other specific selectors
 */

/**
 * Default selector used by Cell2
 */

const makeSelectCell2 = () =>
  createSelector(
    selectCell2Domain,
    substate => substate,
  );

const tryMe = () =>{
  kiko:'mimo'
}
export default makeSelectCell2;
export { selectCell2Domain };
