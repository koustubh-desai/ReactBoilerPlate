/**
 *
 * Cell
 *
 */

import React from 'react';
// import PropTypes from 'prop-types';
// import styled from 'styled-components';

function Cell() {
  return <div className="cell"></div>;
}

Cell.propTypes = {};

export default Cell;
