/**
 *
 * Square
 *
 */

import React from 'react';
import PropTypes from 'prop-types';
import styled from 'styled-components'; 
import './style.css';

function Square({id,val,winBy}) {
  const k = winBy.includes(id)?"cell win":"cell"; 
  return <div id={id} className={k}><span className="player">{val}</span></div>;
}

Square.propTypes = {
  id:PropTypes.number,
  val:PropTypes.string,
  winBy:PropTypes.array
};

export default Square;
