/**
 *
 * Row3
 *
 */

import React from 'react';
import PropTypes from 'prop-types';
import Square from '../Square';
// import styled from 'styled-components';

function Row3({id,xo,winBy}) {
  return <div className='row'>
    <Square id={id*3+0} val={xo[0]} winBy={winBy}/>
    <Square id={id*3+1} val={xo[1]} winBy={winBy}/>
    <Square id={id*3+2} val={xo[2]} winBy={winBy}/>
  </div>;
}

Row3.propTypes = {
  id:PropTypes.number,
  xo:PropTypes.array,
  winBy:PropTypes.array
};

export default Row3;