/**
 *
 * Row
 *
 */

import React from 'react';
import Cell from '../Cell'; 
import Cell2 from '../../containers/Cell2';
import './index.css';
// import PropTypes from 'prop-types';
// import styled from 'styled-components';

function Row() {
  return <div className="row">
    <Cell2/>
    <Cell2/>
    <Cell2/>
  </div>;
}

Row.propTypes = {};

export default Row;
